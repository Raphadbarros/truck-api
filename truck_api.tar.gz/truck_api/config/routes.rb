Rails.application.routes.draw do
  resources :vehicles

  resources :truckers

  scope :api, defaults: { format: :json } do 
    resources :vehicles
    resources :truckers
  end

end
