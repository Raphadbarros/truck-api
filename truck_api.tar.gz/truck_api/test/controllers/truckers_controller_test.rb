require 'test_helper'

class TruckersControllerTest < ActionController::TestCase
  setup do
    @trucker = truckers(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:truckers)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create trucker" do
    assert_difference('Trucker.count') do
      post :create, trucker: { name: @trucker.name, phone: @trucker.phone }
    end

    assert_redirected_to trucker_path(assigns(:trucker))
  end

  test "should show trucker" do
    get :show, id: @trucker
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @trucker
    assert_response :success
  end

  test "should update trucker" do
    patch :update, id: @trucker, trucker: { name: @trucker.name, phone: @trucker.phone }
    assert_redirected_to trucker_path(assigns(:trucker))
  end

  test "should destroy trucker" do
    assert_difference('Trucker.count', -1) do
      delete :destroy, id: @trucker
    end

    assert_redirected_to truckers_path
  end
end
