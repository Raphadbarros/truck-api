require 'test_helper'

class TruckerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
