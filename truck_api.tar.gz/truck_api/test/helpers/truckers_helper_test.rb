require 'test_helper'

class TruckersHelperTest < ActionView::TestCase
end
