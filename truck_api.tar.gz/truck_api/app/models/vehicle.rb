class Vehicle < ActiveRecord::Base
  self.inheritance_column = nil  
  belongs_to :trucker
  accepts_nested_attributes_for :trucker
end
