
class Main < Vehicle
end
