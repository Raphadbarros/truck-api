class Trucker < ActiveRecord::Base
    has_many :vehicle
    accepts_nested_attributes_for :vehicle
end
