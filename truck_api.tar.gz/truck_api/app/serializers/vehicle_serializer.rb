class VehicleSerializer < ActiveModel::Serializer
  attributes :type, :body_type, :board
end
