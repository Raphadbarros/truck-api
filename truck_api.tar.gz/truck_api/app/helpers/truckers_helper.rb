module TruckersHelper
end
